package com.template

data class JsonAnswer(
    val flag:Boolean,
    val url:String,
    val ip:String
)