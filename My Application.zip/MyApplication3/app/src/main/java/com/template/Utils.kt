package com.template

import java.util.*

object Utils {
    const val TAG = "TAG"
    val ID = UUID.randomUUID()
    const val PUTSP = "put"
    var timeZone = TimeZone.getDefault().id
    const val ONE_SIGNAL_APP_ID = "f9db4054-450c-4628-ab97-f6680d1e9d0d"
    const val KEYFORJSON = "urlFromJson"
    const val KEY = "key"


}